let x = 50;
document.write(x);
document.write("<br>")

var y = 50;
document.write(y);
document.write("<br>")

document.write(a);
document.write("<br>")
var a = 25;

document.write(b);
document.write("<br>")
let b = 25;



